import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.PriorityQueue;

public class Test {
    public static void main(String[] args) {
        // try {
        // int[][] matrix = {
        // { 1, 5, 9, 10, 15 },
        // { 10, 11, 13, 16, 20 },
        // { 12, 13, 15, 20, 25 }
        // };
        // int k1 = 15;
        // int k2 = 10;
        // int k3 = 5;
        // // 多种方法获取有序数列中第K个元素的值
        // 1.二分查找测试
        // int x1 = kthSmallest1(matrix, k1);
        // 1.2堆解法测试
        // int x2 = new Test().kthSmallest2(matrix, k2);
        // int x3 = Test.class.getConstructor().newInstance().kthSmallest2(matrix, k3);
        // System.out.println(x1);
        // System.out.println(x2);
        // System.out.println(x3);

        // 重复缺失数字测试
        // int[] nums1 = { 1, 2, 3, 3, 5, 6, 7, 7, 9 };
        // int[][] result = new Test().findErrorNums(nums1);
        // System.out.println("重复的数字:");
        // for (int num : result[0]) {
        // System.out.print(num + " ");
        // }
        // System.out.println("\n缺失的数字:");
        // for (int num : result[1]) {
        // System.out.print(num + " ");
        // }

        // } catch (InstantiationException | IllegalAccessException |
        // NoSuchMethodException e) {
        // e.printStackTrace(); // 打印反射相关异常
        // } catch (InvocationTargetException e) {
        // // 捕获并处理 InvocationTargetException
        // e.printStackTrace(); // 打印封装的异常
        // Throwable cause = e.getCause(); // 获取实际抛出的异常
        // if (cause != null) {
        // cause.printStackTrace(); // 打印实际异常的堆栈信息
        // }
        // }
        // 链表测试
        // LinkedList example = new LinkedList<>();
        // example.add(1);
        // example.add(10);
        // example.addFirst(0);
        // example.add(3, 20);
        // example.addLast(22);
        // System.out.println(example.size());
        // System.out.println("链表内容: " + example);
        // example.removeFirst();
        // System.out.println("链表内容: " + example);

        // 3.数组中求两数之和的坐标测试
        int[] nums2 = { 1, 4, 5, 6, 7, 8, 9 };
        List<int[]> result = new Test().twoSumAll(nums2, 9);

        // 打印结果
        for (int[] pair : result) {
            System.out.println("[" + pair[0] + ", " + pair[1] + "]");
        }

    }

    // 1.1二分查找法获取有序数列中第k的元素值
    public static int kthSmallest1(int[][] matrix, int k) {
        int m = matrix.length, n = matrix[0].length;
        int lo = matrix[0][0], hi = matrix[m - 1][n - 1];
        while (lo <= hi) {
            int mid = lo + (hi - lo) / 2;
            int cnt = 0;
            for (int i = 0; i < m; i++) {
                for (int j = 0; j < n && matrix[i][j] <= mid; j++) {
                    cnt++;
                }
            }
            if (cnt < k)
                lo = mid + 1;
            else
                hi = mid - 1;
        }
        return lo;
    }

    // 1.2堆解法获取有序数列中第k的元素值
    public int kthSmallest2(int[][] matrix, int k) {
        int m = matrix.length, n = matrix[0].length;
        // PriorityQueue：用于在一定顺序（自然顺序）下存储和处理元素，是一个典型的堆数据结构。
        PriorityQueue<Tuple> pq = new PriorityQueue<Tuple>();
        for (int j = 0; j < n; j++)
            // offer方法是添加元素，失败时返回 false，但不会抛出异常。add方法添加失败会抛出 IllegalStateException。
            pq.offer(new Tuple(0, j, matrix[0][j]));
        for (int i = 0; i < k - 1; i++) { // 小根堆，去掉 k - 1 个堆顶元素，此时堆顶元素就是第 k 的数
            // poll方法获取 并移除头部元素，如队列为空则返回'NULL'。
            Tuple t = pq.poll();
            if (t.x == m - 1)
                continue;
            pq.offer(new Tuple(t.x + 1, t.y, matrix[t.x + 1][t.y]));
        }
        return pq.poll().val;
    }

    /**
     * 2.1找到自然整数排序数组中重复的数字和缺失的数字。
     * 
     * @param nums 输入的整数数组，包含从1到n的数字，其中一个数字重复，另一个数字缺失。
     * @return 一个长度为2的数组，第一个元素是重复的数字，第二个元素是缺失的数字。
     */
    public int[][] findErrorNums(int[] nums) {
        List<Integer> duplicates = new ArrayList<>();
        List<Integer> missing = new ArrayList<>();
        int n = nums.length;

        // 遍历数组，将每个数字放到其正确的位置上
        for (int i = 0; i < n; i++) {
            while (nums[i] >= 1 && nums[i] < n && nums[i] != i + 1 && nums[nums[i] - 1] != nums[i]) {
                swap(nums, i, nums[i] - 1);
            }
        }

        // 找到所有不在正确位置的元素
        for (int i = 0; i < n; i++) {
            if (nums[i] != i + 1) {
                duplicates.add(nums[i]); // 记录重复的数字
                missing.add(i + 1); // 记录缺失的数字
            }
        }

        // 将结果转换为二维数组并返回
        int[][] result = new int[2][];
        result[0] = duplicates.stream().mapToInt(Integer::intValue).toArray(); // 重复的数字
        result[1] = missing.stream().mapToInt(Integer::intValue).toArray(); // 缺失的数字

        return result;
    }

    /**
     * 交换数组中的两个元素。
     * 
     * @param nums 要操作的数组
     * @param i    第一个元素的索引
     * @param j    第二个元素的索引
     */
    private void swap(int[] nums, int i, int j) {
        int tmp = nums[i]; // 保存第一个元素的值
        nums[i] = nums[j]; // 将第二个元素的值赋给第一个元素
        nums[j] = tmp; // 将第一个元素的值赋给第二个元素
    }

    /**
     * 3.在一个整数数组中找到两个数，使它们的和等于指定的目标值，并返回这两个数的索引。
     * 
     * @param nums 要操作的数组
     * @param i    第一个元素的索引
     * @param j    第二个元素的索引
     */

    public List<int[]> twoSumAll(int[] nums, int target) {
        HashMap<Integer, Integer> indexForNum = new HashMap<>();
        List<int[]> result = new ArrayList<>();

        for (int i = 0; i < nums.length; i++) {
            int complement = target - nums[i];
            if (indexForNum.containsKey(complement)) {
                result.add(new int[] { indexForNum.get(complement), i });
            }
            indexForNum.put(nums[i], i);
        }

        return result;
    }
}

class Tuple implements Comparable<Tuple> {
    int x, y, val;

    public Tuple(int x, int y, int val) {
        this.x = x;
        this.y = y;
        this.val = val;
    }

    @Override
    public int compareTo(Tuple that) {
        return this.val - that.val;
    }
}
