public class SyncNonBlockingExample {

    private static volatile boolean isTaskDone = false;

    public static void main(String[] args) {
        // 启动异步任务
        new Thread(() -> {
            try {
                Thread.sleep(3000); // 模拟耗时操作
                isTaskDone = true; // 任务完成
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }).start();

        // 主线程进行同步非阻塞的轮询
        while (!isTaskDone) {
            System.out.println("任务尚未完成，继续检查...");
            try {
                Thread.sleep(500); // 等待一段时间后再次检查
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("任务已完成！");
    }
}
