
# 定義









# 画面の初期値セット
DfnBean（Applicationスコープで保持する情報を管理するクラス）を通して、FRAME(图表)+GMN(画面)+ITEM(项目)などの定義表によって、各画面のアップロードをセット。
DBのテーブル内容と合わせて、下記のSQLで抽出する。
```SQL
SELECT 　				 GMN.GMN_ID || ':' || GMN.FRM_CLS MAP_KEY,
						 FRM.TXT_NM FRM_NM,
						 GMN.ITM_NCS,
						 GMN.ITM_ID,
						 GMN.ITM_NM,
						 ITM.ITM_NM ITM_NM_I,
						 ITM.ITM_SHOSU,
						 ITM.ITM_KETA,ITM.ITM_ABT,GMN.ITM_KND,
						 CASE WHEN GMN.ITM_DFLT IS NOT NULL THEN GMN.ITM_DFLT ELSE GMN.ITM_DFLT END ITM_DFLT,
						 GMN.RADIO_GR,
						 GMN.RADIO_VAL,
						 GMN.EXP_IPT,
						 GMN.ITM_VEW,
						 GMN.WIDTH,
						 GMN.TD_WIDTH,
						 GMN.LBL_WIDTH,
						 GMN.SLC_WIDTH,
						 GMN.DATA_TBL,
						 GMN.STYLE,
						 GMN.TD_STYLE,
						 GMN.SRT_NO,  
						 GMN.TAB_INDEX, 
						 GMN.MST, 
						 GMN.LBL_VEW,
						 GMN.CODE 
					 FROM DFN_GMN GMN 
						 LEFT JOIN DFN_ITM ITM ON GMN.ITM_KEY = ITM.ITM_KEY 
						 LEFT JOIN DFN_FRAME FRM ON GMN.GMN_ID = FRM.GMN_ID AND GMN.FRM_CLS = FRM.FRM_CLS 
					 ORDER BY GMN.GMN_ID,GMN.FRM_CLS,GMN.SRT_NO ;
```
