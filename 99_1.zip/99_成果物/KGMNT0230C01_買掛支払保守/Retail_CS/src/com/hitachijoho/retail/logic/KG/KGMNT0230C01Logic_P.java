//--2016/08/01 ACEカスタマイズ対応 
package com.hitachijoho.retail.logic.KG;

import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import javax.faces.FacesException;
import javax.faces.context.FacesContext;
import javax.faces.model.DataModel;
import javax.faces.model.ListDataModel;
import javax.servlet.http.HttpServletRequest;
import javax.sql.RowSet;

import com.hitachijoho.retail.common.CommonAjaxBean;
import com.hitachijoho.retail.common.CommonGNR;
import com.hitachijoho.retail.common.CommonMethod;
import com.hitachijoho.retail.common.CommonProcedure;
import com.hitachijoho.retail.common.Const;
import com.hitachijoho.retail.common.func.ClsDay;
import com.hitachijoho.retail.logic.MS.MSMDL0010F01Logic;

/**　買掛支払保守　業務処理							
 * @author syou　2012/03/20	
 * @history whizen syou 2012/04/11  ピックアップテスト No.28　対応
 * 			whizen syou 2012/04/11     ピックアップテスト No.29　対応							
 *			whizen syou 2012/04/11  2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加		
 * @history whizen syou 2012/04/19   【BERS2CT-000111対応】		
 * @history HISYS syou 2012/11/15   CTBUG BISG00002-000007　対応	
 * @history HISYS kyo 2013/01/16 Update 運用テストNo32,33対応	
 */	
public class KGMNT0230C01Logic_P {

	//ページロードメソッド
	public void KGMNT0230C01Page_Load(){
		
		//画面初期化を行う
		CommonGNR.setGamenItemInit("KGMNT0230C","01");
		//DataTable初期化を行う
		CommonMethod.setModelData("KGMNT0230C", "01", "001", new ListDataModel());
		
		//初期表示を行う
		//対象年月<-事業部マスタの当月買掛締日（VS#KAIKAKEDT8）の先頭６桁
		CommonMethod.setItemValue("KGMNT0230C", "01", "SELDTYM001", 
					CommonMethod.getSessionValue("KAIKAKEDT8").substring(0, 6));
		//締日<-事業部マスタの買掛締日（VS#KAIKAKEDT）
		CommonMethod.setItemValue("KGMNT0230C", "01", "SIME", CommonMethod.getSessionValue("KAIKAKEDT"));
		
		//項目活性制御を行う
		//[買掛明細]グループの全項目を非活性にする															
		CommonMethod.setAllDisabled("KGMNT0230C", "01", true);
		//[支払明細]グループの全項目を非活性にする
		CommonMethod.setAllDisabled_DataTable("KGMNT0230C", "01", "001", true);
		//[フッタ]グループの全項目を非活性にする
		CommonMethod.setAllDisabled_FootBtn("KGMNT0230C", "01", true);
		//[見出し]グループの全項目を活性にする
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "SELDTYM001", false);
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "SIME", false);       //--2016/08/01 ADD
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "DSHICD", false);
		//[照会]を活性にする	
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F01", false);
		//[代表仕入先検索]を活性にする	
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F08", false);
		//【20121115】【syou】【BISG00002-000007の対応】【開始】
		//2012/08/20 CS対応
		//[次へ]を活性にする
		//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F09", false);
		//2012/08/20 CS対応
		//【20121115】【syou】【BISG00002-000007の対応】【終了】
		//[ｷｬﾝｾﾙ]を活性にする		
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F11", false);
		//[終了]を活性にする
		CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F12", false);
		
		//[代表仕入先コード]にフォーカス設定する
		CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");

		//2012/08/20 CS対応
		//税計算する為の税率を取得
		//WK_ZEIRT← #[ZEIRT]　/　100
		CommonProcedure comProc = new CommonProcedure();
		comProc.selectProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01S006");
		String strZEIRT = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_ZEIRT").FldValue;
		BigDecimal bigZEIRT = new BigDecimal(strZEIRT);
		bigZEIRT.divide(new BigDecimal("100"), BigDecimal.ROUND_HALF_UP);
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_ZEIRT", String.valueOf(bigZEIRT.doubleValue()));
		//2012/08/20 CS対応
	}

	/**　F01ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F01_Click(){
		
		try {
			//必須チェックを行う
			if(!CommonGNR.chkNcsItem("KGMNT0230C", "01")){
				return "";
			}
			//属性チェックを行う
			if(!CommonGNR.chkDtlItem("KGMNT0230C", "01")){
				return "";
			}
			//業務チェックを行う
			KGMNT0230C01Check chk = new KGMNT0230C01Check();
			if (!chk.F01_Check()) {
				return "";
			}
			//データを取得する
			CommonProcedure comProc = new CommonProcedure();
			//買掛マスタより該当レコードを取得し、表示を行なう
			comProc.selectProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01S002");
			//買掛支払トランより該当レコードを取得し、表示を行なう
			comProc.selectProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01S003");
			//2023/09/13_KDP導入_sys.担当F2_ADD_START
			//買掛バッチスケジュールマスタ「処理フラグ」の取得を行ない、現在の状態の判別を行なう。
			RowSet rs = null;
			comProc.InputData.put("SHRID","KGBAT6060C");
			rs = comProc.selectProcedure_RtnSet("KGMNT0230C", "01","PS_KGMNT0230C01S010");
			String strWK_SHRFLG = "";
			try {
				while(rs.next()) {
					strWK_SHRFLG = rs.getString("WK_SHRFLG");
				}
				rs.close();
			} catch (Exception e) {
				throw new FacesException(e);
			}
			//2023/09/13_KDP導入_sys.担当F2_ADD_END
			//画面制御を行う
			//(1) [見出し]グループの全項目を非活性にする。																			
			//(2) [買掛明細]グループの全項目を非活性にする。
			CommonMethod.setAllDisabled("KGMNT0230C", "01", true);
			//(3) [支払明細]グループの全項目を非活性にする。	
			CommonMethod.setAllDisabled_DataTable("KGMNT0230C", "01", "001", true);
			//2023/10/11_KDP導入_sys.担当F2_DEL_仕様変更履歴№14_START
			////(4) [フッタ]グループの全項目を非活性にする。
			//CommonMethod.setAllDisabled_FootBtn("KGMNT0230C", "01", true);
			////2012/08/20 CS対応
			////[次へ]を活性にする
			//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F09", false);
			////2012/08/20 CS対応
			////[ｷｬﾝｾﾙ]を活性にする		
			//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F11", false);
			////[終了]を活性にする
			//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F12", false);
			//2023/10/11_KDP導入_sys.担当F2_DEL_仕様変更履歴№14_END
			
			//--2016/08/01 ADD Start -----------------------------
			////(5) [対象年月]が当月(VS#KAIKAKEDT8の先頭６桁)の場合
			//String strTaisyoYM = CommonMethod.getItemValue("KGMNT0230C","01", "SELDTYM001").FldValue;
			//if (strTaisyoYM.equals(CommonMethod.getSessionValue("KAIKAKEDT8").substring(0, 6))) {
			
			//対象終了日([対象年月]&[対象締日])
			String strWK_ENDYMD = CommonMethod.getItemValue("KGMNT0230C","01", "WK_ENDYMD").FldValue;
			//対象終了日が当月の場合
			//2023/09/13_KDP導入_sys.担当F2_MOD_START
			//if (strWK_ENDYMD.equals(CommonMethod.getSessionValue("KAIKAKEDT8")){
			if (strWK_ENDYMD.equals(CommonMethod.getSessionValue("KAIKAKEDT8")) && String.valueOf(Const.cKGSHRFLG_Mishori).equals(strWK_SHRFLG)) {
			//2023/09/13_KDP導入_sys.担当F2_MOD_END
			//--2016/08/01 ADD End   -----------------------------
				
				//① [買掛明細]グループの活性制御する。	
				//[消費税]を活性にする。（当月消費税額）
				CommonMethod.setItemDisabled("KGMNT0230C", "01", "TOUZEI", false);
				//[消費税]を活性にする。（当月発生相殺税額）	
				//2012/08/20 CS対応
				//CommonMethod.setItemDisabled("KGMNT0230C", "01", "HASSEISOSAI_ZEI", false);
				//2012/08/20 CS対応
				//② [支払明細]グループの活性制御する。																	
				//[支払種別]を活性にする。
				int rowCount = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
				for (int i = 0;i < rowCount;i++) {
					//2023/09/13_KDP導入_sys.担当F2_ADD_START
					//[支払明細][発生締日] ≧ 対象締日([基本_見出し][対象年月]＆[基本_見出し][対象締日]の場合
					if (strWK_ENDYMD.compareTo(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "HSIYYMMDD")) <= 0) {
					//2023/09/13_KDP導入_sys.担当F2_ADD_END
						//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_START
						//支払種別
						String strSIHCD = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD");
						if (Const.cPayCode_UserSet10 < Integer.valueOf(strSIHCD)) {
							//[支払種別]を活性にする
							CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "SIHCD", "001", false);
						}
						//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_END
						//[支払額（税込）]を活性にする。	
						CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "SIHKN", "001", false);
						//[内消費税]を活性にする。
						//2012/08/20 CS対応
						CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "ZEIKN", "001", false);
						//2012/08/20 CS対応
						//2012/09/18 B票対応
						//20130116 kyo 運用テストNo32対応　STR
						//2023/09/13_KDP導入_sys.担当F2_MOD_START
						//[支払予定日]を活性にする。
						//CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "SHRDD", "001", false);
						//[支払予定日]を非活性にする。
						CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "SHRDD", "001", true);
						//2023/09/13_KDP導入_sys.担当F2_MOD_END
						//20130116 kyo 運用テストNo32対応　END
						//2012/09/18 B票対応
						//[支払日]を活性にする。	
						CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "SHIHARAIBI", "001", false);
						//[備考]を活性にする。
						CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", i, "BIKO", "001", false);
					//2023/09/13_KDP導入_sys.担当F2_ADD_START
					}
					//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_START
					//支払種別1を設定する
					//CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHCD1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD"));
					//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_END
					//支払額1を設定する
					CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHKN1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN"));
					//内消費税1を設定する
					CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_ZEIKN1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN"));
					//2023/09/13_KDP導入_sys.担当F2_ADD_END
				}
				//2023/10/11_KDP導入_sys.担当F2_DEL_仕様変更履歴№14_START
				////③ [フッタ]グループの活性制御する。																	
				////[更新]を活性にする。		
				//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F02", false);
				////[計算]を活性にする。
				//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F04", false);
				////[行追加]を活性にする。
				//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F05", false);
				////[行削除]を活性にする。
				//CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F07", false);
				//2023/10/11_KDP導入_sys.担当F2_DEL_仕様変更履歴№14_END
			}
			//2023/10/11_KDP導入_sys.担当F2_ADD_仕様変更履歴№14_START
			//(8)ファンクションボタンの制御
			if (strWK_ENDYMD.equals(CommonMethod.getSessionValue("KAIKAKEDT8"))) {
				//a）対象締日([基本_見出し][対象年月]＆[基本_見出し][対象締日]※)が、事業部マスタ.当月買掛締日(８桁)　の場合
				if (String.valueOf(Const.cKGSHRFLG_ShoriZumi).equals(strWK_SHRFLG)) {
					//a-1） 買掛バッチスケジュールマスタで対象月の処理「支払条件一括変更」の処理フラグが処理済み(※A)　の場合
					//※A：「支払条件一括変更」前の処理が再実行され、「支払条件一括変更」を再実行する必要があるケースは「a-2」とする。
					//[次へ(F09)]、[ｷｬﾝｾﾙ (F11)]、[終了(F12)]
					//[フッタ]グループの全項目を非活性にする。
					CommonMethod.setAllDisabled_FootBtn("KGMNT0230C", "01", true);
					//[次へ]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F09", false);
					//[ｷｬﾝｾﾙ]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F11", false);
					//[終了]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F12", false);
				} else {
					//a-2）a-1外の場合
					//下記のァンクションボタンを活性とし、その他は非活性とする。【現状通り】
					//[更新(F02)]、[計算](F04)]、[行追加(F05)]、[行削除(F07)]、[次へ(F09)]、[ｷｬﾝｾﾙ (F11)]、[終了(F12)]
					//[フッタ]グループの全項目を非活性にする。
					CommonMethod.setAllDisabled_FootBtn("KGMNT0230C", "01", true);
					//[更新]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F02", false);
					//[計算]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F04", false);
					//[行追加]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F05", false);
					//[行削除]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F07", false);
					//[次へ]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F09", false);
					//[ｷｬﾝｾﾙ]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F11", false);
					//[終了]を活性にする
					CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F12", false);
				}
			} else {
				//b）a以外の場合
				//下記のァンクションボタンを活性とし、その他は非活性とする。【現状通り】
				//[次へ(F09)]、[ｷｬﾝｾﾙ (F11)]、[終了(F12)]
				//[フッタ]グループの全項目を非活性にする。
				CommonMethod.setAllDisabled_FootBtn("KGMNT0230C", "01", true);
				//[次へ]を活性にする
				CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F09", false);
				//[ｷｬﾝｾﾙ]を活性にする
				CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F11", false);
				//[終了]を活性にする
				CommonMethod.setItemDisabled("KGMNT0230C", "01", "BTN_F12", false);
			}
			//2023/10/11_KDP導入_sys.担当F2_ADD_仕様変更履歴№14_END
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F02ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F02_Click(){
		
		CommonProcedure comProc = null;
		try {
			//必須チェックを行う
			if(!CommonGNR.chkNcsItem("KGMNT0230C", "01")){
				return "";
			}
			//属性チェックを行う
			if(!CommonGNR.chkDtlItem("KGMNT0230C", "01")){
				return "";
			}
			//画面項目の再計算処理を行う
			CalcSum();
			//業務チェックを行う
			KGMNT0230C01Check chk = new KGMNT0230C01Check();
			if (!chk.F02_Check()) {
				return "";
			}
			//2023/09/13_KDP導入_sys.担当F2_ADD_START
			//確認メッセージを表示する。
			String strHid_Err_Flg = CommonMethod.getItemValue("KGMNT0230C", "01", "HID_ERR_FLG").FldValue;
			int rowCount = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
			for (int i = 0;i < rowCount;i++) {
				//支払種別
				String strSIHCD = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD");
				//支払額（税込）
				String strSIHKN = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN");
				//内消費税
				String strZEIKN = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN");
				//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_START
				//支払種別1
				//String strWKSIHCD1 = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHCD1");
				//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_END
				//支払額1
				String strWKSIHKN1 = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHKN1");
				//内消費税1
				String strWKZEIKN1 = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "WK_ZEIKN1");
				//[支払明細][支払種別]が自動計算相殺区分 かつ [支払明細][支払額（税込）]、[支払明細][内消費税]が照会ボタン押下時点に表示された値と異なる場合、警告メッセージを
				if (Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01
					|| (Integer.valueOf(strSIHCD) >= Const.cPayCode_UserSet01 && Integer.valueOf(strSIHCD) <= Const.cPayCode_UserSet10)) {
					//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_START
					//if (!strSIHCD.equals(strWKSIHCD1) || !strSIHKN.equals(strWKSIHKN1) || !strZEIKN.equals(strWKZEIKN1)) {
					if (!strSIHKN.equals(strWKSIHKN1) || !strZEIKN.equals(strWKZEIKN1)) {
					//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_END
						if ("".equals(strHid_Err_Flg)) {
							// 警告メッセージを表示し取込処理を終了、フォーカスを[更新]に設定する。
							CommonMethod.setErrorDialog("KGMNT0230C", "01", "BTN_F02", "W60010", "");
							return "";
						} else if ("N".equals(strHid_Err_Flg)) {
							//[いいえ]を押下の場合、フォーカスを[支払種別]に設定する。
							CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SIHCD");
							return "";
						}
					}
				}
				
			}
			//2023/09/13_KDP導入_sys.担当F2_ADD_END
			//ＤＢ登録・更新処理を行う
			//買掛支払トラン更新対象外
			comProc = new CommonProcedure();
			comProc.begin();
			//買掛マスタデータを更新する
			//【20120419】 【肖】 【BERS2CT-000111対応】 【開始】
			//comProc.updateProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01U001");
			comProc.updateProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01U001");
			//買掛支払トランデータを削除する
			//comProc.updateProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01D001");
			//2023/09/13_KDP導入_sys.担当F2_MOD_START
			//2023/09/22_KDP導入_sys.担当F2_MOD_KG-UT-B013_START
			comProc.updateProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01D001");
			//comProc.updateProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01D001");
			//2023/09/22_KDP導入_sys.担当F2_MOD_KG-UT-B013_END
			//2023/09/13_KDP導入_sys.担当F2_MOD_END
			//【20120419】 【肖】 【BERS2CT-000111対応】 【終了】
			//買掛支払トランデータを登録する
			comProc.updateProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01I001");
			
			comProc.commit();
			
			//「ロード処理」を行う
			//20130116 kyo 運用テストNo33対応　STR
			//KGMNT0230C01Page_Load();
			//20130116 kyo 運用テストNo33対応　END
			//2023/09/13_KDP導入_sys.担当F2_ADD_START
			//[支払明細]グループを取得
			int rowCnt = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
			for (int i = 0; i < rowCnt; i++) {
				//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_START
				//支払種別1を設定する
				//CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHCD1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD"));
				//2023/09/22_KDP導入_sys.担当F2_DEL_仕様変更履歴№10_END
				//支払額1を設定する
				CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_SIHKN1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN"));
				//内消費税1を設定する
				CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "WK_ZEIKN1", CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN"));
			}
			//2023/09/13_KDP導入_sys.担当F2_ADD_END
			return "";
		} catch(Exception e){
			if(comProc != null){ 
				comProc.rollback();
			}
			throw new FacesException(e);
		}
	}
	
	/**　F03ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F03_Click(){
		
		try {
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F04ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F04_Click(){
		
		try {
			//必須チェックを行う
			if(!CommonGNR.chkNcsItem("KGMNT0230C", "01")){
				return "";
			}
			//属性チェックを行う
			if(!CommonGNR.chkDtlItem("KGMNT0230C", "01")){
				return "";
			}
			
			//画面項目の再計算処理を行う
			//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を修正   S  
			//CalcSum();
			if(!CalcSum()){
				return "";
			}
			//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を修正   E  
			//再計算結果（ワークエリア）を画面項目にセットする
			//当月仕入額←WK_当月仕入額
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOUSIR_CAL", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSIR_CAL").FldValue);
			//当月支払額（税込）←WK_当月支払額（税込）
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOUHAR", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR").FldValue);
			//当月相殺額（税込）←WK_当月相殺額（税込）
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOUSOU", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSOU").FldValue);
			//当月支払合計←WK_当月支払合計
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOUHAR_CAL", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR_CAL").FldValue);
			//当月残高←WK_当月残高
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOUZAN", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUZAN").FldValue);
			//当月発生支払予定←WK_当月発生支払予定	
			CommonMethod.setItemValue("KGMNT0230C", "01", "HASSEIYOTEI", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_HASSEIYOTEI").FldValue);
			//当月保留額←WK_当月保留額
			CommonMethod.setItemValue("KGMNT0230C", "01", "TOURYUHO", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOURYUHO").FldValue);
			
			//ピックアップテスト No.28　対応追加　S
			//WK_支払予定金額1←WK_支払予定金額11
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI1", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI11").FldValue);
			//WK_支払予定金額2←WK_支払予定金額22
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI2", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI22").FldValue);
			//WK_支払予定金額3←WK_支払予定金額33
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI3", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI33").FldValue);
			//WK_支払予定金額4←WK_支払予定金額44
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI4", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI44").FldValue);
			//WK_支払予定金額5←WK_支払予定金額55
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI5", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI55").FldValue);
			//WK_支払予定金額6←WK_支払予定金額66
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI6", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI66").FldValue);
			
			//WK_支払予定消費税額1←WK_支払予定消費税額11
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI1", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI11").FldValue);
			//WK_支払予定消費税額2←WK_支払予定消費税額22
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI2", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI22").FldValue);
			//WK_支払予定消費税額3←WK_支払予定消費税額33
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI3", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI33").FldValue);
			//WK_支払予定消費税額4←WK_支払予定消費税額44
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI4", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI44").FldValue);
			//WK_支払予定消費税額5←WK_支払予定消費税額55
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI5", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI55").FldValue);
			//WK_支払予定消費税額6←WK_支払予定消費税額66
			CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI6", CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI66").FldValue);
			//ピックアップテスト No.28　対応追加　E
			
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F05ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F05_Click(){
		
		try {
			//１行空白行を追加する
			CommonMethod.addRowModelData("KGMNT0230C", "01", "001");
			//追加された空白行の行番号を取得する
			int index = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001") - 1;
			//追加された行にデフォルト値を設定する
			CommonMethod.setRowModelData("KGMNT0230C", "01", "001", index,
					"WK_DTKBN", String.valueOf(Const.cDATKBN_Tenyuryoku));
			
			//追加された行の項目活性制御を行う
			//--2016/08/01 MOD Start -----------------------------
			////[発生月]を活性にする	
			//CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "HSIYYMM", "001", false);
			//[発生締日]を活性にする
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "HSIYYMMDD", "001", false);
			//--2016/08/01 MOD End   -----------------------------
			//[支払種別]を活性にする	
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "SIHCD", "001", false);
			//[支払種別名]を非活性にする
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "TEKIYO", "001", true);
			//[支払額（税込）]を活性にする。	
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "SIHKN", "001", false);
			//2012/08/20 CS対応
			////[内消費税]を活性にする。
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "ZEIKN", "001", false);
			//CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "ZEIKN", "001", true);
			//2012/08/20 CS対応
			//2023/09/13_KDP導入_sys.担当F2_MOD_START
			//[支払予定日]を活性にする。
			//CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "SHRDD", "001", false);
			//[支払予定日]を非活性にする
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "SHRDD", "001", true);
			//2023/09/13_KDP導入_sys.担当F2_MOD_END
			//[支払日]を活性にする。	
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "SHIHARAIBI", "001", false);
			//[備考]を活性にする。
			CommonMethod.setRowModelDisabled("KGMNT0230C", "01", "001", index, "BIKO", "001", false);
			
			//--2016/08/01 MOD Start -----------------------------
			////追加された空白行の[発生月]にフォーカスを設定する
			//CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", index+":HSIYYMM");
			//追加された空白行の[発生締日]にフォーカスを設定する
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", index+":HSIYYMMDD");
			//--2016/08/01 MOD End   -----------------------------
			
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F06ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F06_Click(){
		
		try {
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F07ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F07_Click(){
		
		try {
			//項目取得を行う
			String strItemVal = CommonMethod.getItemValue("KGMNT0230C", "01", "HID_ERR_FLG").FldValue;
			String strRowNo = CommonMethod.getItemValue("KGMNT0230C", "01", "HID_SCT_ROWNO").FldValue;
			int rowCount = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
			//ピックアップテスト No.29　対応削除　S
//			int intRowNo = 0;
//			//行が選択されていない場合はエラーとする
//			if ("".equals(strRowNo) || rowCount == 0) {
//				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04330", "");
//				//行が存在しない場合
//				if (rowCount < 0) {
//					//[消費税]にフォーカス設定にする
//					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "HASSEISOSAI_ZEI");
//				} else {
//					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "BTN_F07");
//				}
//				return "";
//			} else {
//				intRowNo = Integer.parseInt(strRowNo);
//			}
			//ピックアップテスト No.29　対応削除　E
			if ("Y".equals(strItemVal)) {
				//ピックアップテスト No.29　対応追加　S
				int intRowNo = Integer.parseInt(strRowNo);
				//ピックアップテスト No.29　対応追加　E
				//[はい]を押下の場合、次の処理へ進む
				//対象行の削除（行の移動）を行う
				Object Obj = CommonMethod.getBeanObject("KGMNT0230C", "01");
				Class cls = Obj.getClass();
				Method getMtd = cls.getMethod("getResultData" + "001");
				Object getObj = getMtd.invoke(Obj);
				DataModel datamodel = (DataModel)getObj;
				ArrayList arData = (ArrayList)datamodel.getWrappedData();
				arData.remove(intRowNo);
				CommonMethod.setModelData("KGMNT0230C", "01", "001", new ListDataModel(arData));
				
				//フォーカスを移動させる
				//削除行-１の[発生締日]が活性の場合,削除行-１の[発生締日]にフォーカス設定する
				int intRowNoS = intRowNo - 1;
				if (intRowNo == 0) {
					intRowNoS = 0;
				}
				//--2016/08/01 MOD Start -----------------------------
				//if (CommonMethod.getRowModelDisabled("KGMNT0230C", "01", "001", intRowNoS, "HSIYYMM").toString().equals("inline")) {
				//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + String.valueOf(intRowNoS) +":HSIYYMM");
				if (CommonMethod.getRowModelDisabled("KGMNT0230C", "01", "001", intRowNoS, "HSIYYMMDD").toString().equals("table-cell")) {
					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + String.valueOf(intRowNoS) +":HSIYYMMDD");
				//--2016/08/01 MOD End   -----------------------------
				}else {
					//削除行-１の[発生締日]が非活性の場合,削除行-１の[支払種別]にフォーカス設定する
					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + String.valueOf(intRowNoS) +":SIHCD");
				}
			} else if ("N".equals(strItemVal)) {
				//[いいえ]を押下の場合、フォーカスを選択行の支払明細[支払種別]に設定する
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + strRowNo +":SIHCD");
				return "";
			} else {
				//ピックアップテスト No.29　対応追加　S
				//行が選択されていない場合はエラーとする
				if ("".equals(strRowNo) || rowCount == 0) {
					CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04330", "");
					//行が存在しない場合
					if (rowCount < 0) {
						//[消費税]にフォーカス設定にする
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "HASSEISOSAI_ZEI");
					} else {
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "BTN_F07");
					}
					return "";
				}
				//ピックアップテスト No.29　対応追加　E
				
				//--2024/05/09 ADD-Str sys.Endo
				//--過去の発生締日分は削除できないチェックを追加
				int intChkRowNo = Integer.parseInt(strRowNo);
				//発生締日
				String strHSIYYMMDD = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", intChkRowNo, "HSIYYMMDD"));
				//セッション変数[前月買掛締日]
				String strZEN_KAIKAKEDT = CommonMethod.getSessionValue("ZEN_KAIKAKEDT");
				if (!"".equals(strHSIYYMMDD)) {
					//新規入力業でない場合のみ
					if (!CommonMethod.getRowModelDisabled("KGMNT0230C", "01", "001", intChkRowNo, "HSIYYMMDD").toString().equals("table-cell")){
						//[発生締日]=＜セッション変数[前月買掛締日]の場合はエラーとする。
						//エラーメッセージ：E00910（は削除できません。）
						if (strHSIYYMMDD.compareTo(strZEN_KAIKAKEDT) <= 0 ){
							CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00910", "過去発生締日の相殺");
							return "";
						}
					}
				}
				//--2024/05/09 ADD-End sys.Endo
				
				
				//削除確認メッセージを表示する
				//ピックアップテスト No.29　対応修正　S
				//CommonMethod.setErrorDialog("KGMNT0230C", "01", "BTN_F07", "Q00110", intRowNo+1 + "行目");
				//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_START
				int intRowNo = Integer.parseInt(strRowNo);
				Object Obj = CommonMethod.getBeanObject("KGMNT0230C", "01");
				Class cls = Obj.getClass();
				Method getMtd = cls.getMethod("getResultData" + "001");
				Object getObj = getMtd.invoke(Obj);
				DataModel datamodel = (DataModel)getObj;
				ArrayList arData = (ArrayList)datamodel.getWrappedData();
				Map arRow = (HashMap)arData.get(intRowNo);
				//--2024/05/09 ADD 未入力項目かの確追加　sys.Endo
				if (!"".equals((String) arRow.get("SIHCD"))) {
					if (Const.cPayCode_UserSet10 < Integer.parseInt((String) arRow.get("SIHCD"))) {
						CommonMethod.setErrorDialog("KGMNT0230C", "01", "BTN_F07", "Q00110", Integer.parseInt(strRowNo)+1 + "行目");
					}
					else {
						CommonMethod.setErrorDialog("KGMNT0230C", "01", "BTN_F07", "Q60020", Integer.parseInt(strRowNo)+1 + "行目");
					}
				}else {
					CommonMethod.setErrorDialog("KGMNT0230C", "01", "BTN_F07", "Q00110", Integer.parseInt(strRowNo)+1 + "行目");
				}
				
				//2023/09/22_KDP導入_sys.担当F2_MOD_仕様変更履歴№10_END
				//ピックアップテスト No.29　対応修正　S
			}	
			
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F08ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F08_Click(){
		
		try {
			String cmd = CommonMethod.getItemValue("KGMNT0230C", "01", "HID_SUB_CMD").FldValue;
			if(cmd.equals("")){
				//パラメータの設定を行う
				CommonMethod.setItemValue("MSMDL0010F", "01", "WK_GMNM", "仕入先名（漢字）");
				CommonMethod.setItemValue("MSMDL0010F", "01", "WK_CD", "SHICD");
				CommonMethod.setItemValue("MSMDL0010F", "01", "WK_NM", "SHIKJ");
				CommonMethod.setItemValue("MSMDL0010F", "01", "WK_TBLNM", "SHIMST");
				//共通検索画面を起動する
				MSMDL0010F01Logic logic = new MSMDL0010F01Logic();
				logic.MSMDL0010F01Page_Load();
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_SUB_CMD", "OPEN");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_SUB_URL", "../MS/MSMDL0010F01.jsp");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "BTN_F08");
				CommonMethod.setItemValue("MSMDL0010F", "01", "HID_SUB_CMD", "");
			}
			else if(cmd.equals("SUBMIT")){
				String strWkHkCd = CommonMethod.getItemValue("MSMDL0010F", "01", "WK_HKCD").FldValue;
				if (!"".equals(strWkHkCd)) {
					CommonMethod.setItemValue("KGMNT0230C", "01", "DSHICD", strWkHkCd);
				}
				//フォーカスを[代表仕入先コード]に設定する
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");
				
			}
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F09ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F09_Click(){
		
		try {
			//2012/08/20 CS対応
			//買掛マスタの次レコードの値を取得する
			//次レコードが存在しない場合はエラー
			CommonProcedure comProc = new CommonProcedure();
			comProc.selectProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01S007");
			String strNEXT_DSHICD = CommonMethod.getItemValue("KGMNT0230C", "01", "NEXT_DSHICD").FldValue;
			if("".equals(strNEXT_DSHICD)){
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00430", "次のレコード");
				return "";
			}
			//[代表仕入先コード]←#[NEXT_DSHICD]
			CommonMethod.setItemValue("KGMNT0230C", "01", "DSHICD", strNEXT_DSHICD);
			//Ｆ１（照会）処理を行う
			CommonMethod.setModelData("KGMNT0230C", "01", "001", new ListDataModel());
			BTN_F01_Click();

			//※　次へ押下時に入力チェックは行なわない
			//　　運用についてユーザと確認した上で変更チェックを行なわないようにした。20120711ユーザ打合せにて確認済み（東様）
			//2012/08/20 CS対応
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F10ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F10_Click(){
		
		try {
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F11ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F11_Click(){
		
		try {
			KGMNT0230C01Page_Load();
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　F12ボタンクリック
	 * @return　画面遷移ID
	 */
	public String BTN_F12_Click(){
		
		try {
			return "C02";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**　ダブルクリック
	 * @return　画面遷移ID
	 */
	public String DBL_Click(){
		
		try {
			return "";
		} catch(Exception e){
			throw new FacesException(e);
		}
	}
	
	/**
	 * 行削除のとき、合計項目の再計算
	 * @throws Exception 
	 * @throws NumberFormatException 
	 * 
	 */
	//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を修正   S  
	//private void CalcSum() throws NumberFormatException, Exception {
	private boolean CalcSum() throws NumberFormatException, Exception {
    //2012.4.10 仕様変更 計算結果が桁数オーバーの確認を修正   S  
		//画面項目の再計算を行いワークエリアにセットする
		
		//WK_当月仕入額←[仕入] - [返品] - [値引] + [当月消費税額]
		String strTOUSIR = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUSIR").FldValue;
		String strTOUHPN = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUHPN").FldValue;
		String strTOUNBK = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUNBK").FldValue;
		//2012/08/20 CS対応
		String strTOUWARI = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUWARI").FldValue;
		//2012/08/20 CS対応
		String strTOUZEI = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUZEI").FldValue;
		BigDecimal strTOUSIR_CAL = new BigDecimal(0);
		//ピックアップテスト No.28　対応修正　S
		//strTOUSIR_CAL = getZeroWhenNull(strTOUSIR).subtract(new BigDecimal(CommonMethod.changeZero(strTOUHPN)))
		//				.subtract(new BigDecimal(CommonMethod.changeZero(strTOUNBK)).add(getZeroWhenNull(strTOUZEI)));
		strTOUSIR_CAL = getZeroWhenNull(strTOUSIR).subtract(new BigDecimal(CommonMethod.changeZero(strTOUHPN)))
					    //2012/08/20 CS対応
					//    .subtract(new BigDecimal(CommonMethod.changeZero(strTOUNBK))).add(getZeroWhenNull(strTOUZEI));
					    .subtract(new BigDecimal(CommonMethod.changeZero(strTOUNBK))).add(getZeroWhenNull(strTOUZEI))
					    .subtract(new BigDecimal(CommonMethod.changeZero(strTOUWARI)));
					    //2012/08/20 CS対応
		//ピックアップテスト No.28　対応修正　S
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOUSIR_CAL", strTOUSIR_CAL.toString());
		
		int rowCount = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
		//対象年月
		String strSELDTYM001 = CommonMethod.getItemValue("KGMNT0230C", "01", "SELDTYM001").FldValue;
		//当月支払額（税込）合計
		BigDecimal lTOUHAR_CAl = new BigDecimal(0);
		//当月相殺額（税込）合計
		BigDecimal lTOUSOU_CAl = new BigDecimal(0);
		//支払明細の[支払額（税込）]合計
		BigDecimal lSIHKN = new BigDecimal(0);
		//支払予定金額1合計
		BigDecimal lWK_SYOTEI1 = new BigDecimal(0);
		//支払予定金額2合計
		BigDecimal lWK_SYOTEI2 = new BigDecimal(0);
		//支払予定金額3合計
		BigDecimal lWK_SYOTEI3 = new BigDecimal(0);
		//支払予定金額4合計
		BigDecimal lWK_SYOTEI4 = new BigDecimal(0);
		//支払予定金額5合計
		BigDecimal lWK_SYOTEI5 = new BigDecimal(0);
		//支払予定金額6合計
		BigDecimal lWK_SYOTEI6 = new BigDecimal(0);
		//支払予定消費税額1合計
		BigDecimal lWK_SZYOTEI1 = new BigDecimal(0);
		//支払予定消費税額2合計
		BigDecimal lWK_SZYOTEI2 = new BigDecimal(0);
		//支払予定消費税額3合計
		BigDecimal lWK_SZYOTEI3 = new BigDecimal(0);
		//支払予定消費税額4合計
		BigDecimal lWK_SZYOTEI4 = new BigDecimal(0);
		//支払予定消費税額5合計
		BigDecimal lWK_SZYOTEI5 = new BigDecimal(0);
		//支払予定消費税額6合計
		BigDecimal lWK_SZYOTEI6 = new BigDecimal(0);
		
		//--2016/08/01 ADD Start -----------------------------
		RowSet retRS = null;
		//処理開始日
		String strWkSTADT[] = new String[7];
		//処理終了日
		String strWkENDDT[] = new String[7];
		
		try{
			CommonProcedure comProc = new CommonProcedure();
			retRS = comProc.selectProcedure_RtnSet("KGMNT0230C", "01", "PS_KGMNT0230C01S008");
			if (retRS.next()) {
				for (int j = 0; j < 7; j++) {
					//処理開始日
					strWkSTADT[j] = CommonMethod.exchangeNull(retRS.getString("WK_STRYMD"+j));
					//処理終了日
					strWkENDDT[j] = CommonMethod.exchangeNull(retRS.getString("WK_ENDYMD"+j));
				}
			}
		}finally {
			if(retRS != null){ 
				retRS.close();
			}
		}
		//--2016/08/01 ADD End   -----------------------------
		
		ClsDay clsDay = new ClsDay();
		for (int i = 0; i < rowCount; i++) {
			//支払明細の[支払日]
			String strSHIHARAIBI = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SHIHARAIBI");
			//支払明細の[支払予定日]
			String strSHRDD = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SHRDD");
			//2012/09/28 B票対応
			//2012/10/02 B票対応
			if(!"".equals(strSHIHARAIBI)){
				if(Integer.parseInt(strSHIHARAIBI) == 0){
					strSHIHARAIBI = "";
				}
			}
			if(!"".equals(strSHIHARAIBI)){
				strSHRDD = strSHIHARAIBI;
			}//else if(strSELDTYM001.equals(strSHRDD.substring(0,6))){
//				strSHRDD = clsDay.CalDay(strSHRDD, 1, 1);
//			}
			//2012/10/02 B票対応
			//2012/09/28 B票対応
			//支払明細の[支払種別]
			String strSIHCD = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD");
			//支払明細の[支払額（税込）]
			String strSIHKN = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN");
			//支払明細の[内消費税]
			String strZEIKN = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN");
			
			if ((strSHRDD != null && !"".equals(strSHRDD)) 
					&& (strSIHCD != null && !"".equals(strSIHCD))) {
				
				//--2016/08/01 MOD Start -----------------------------
				////2012/09/18 B票対応
				//////WK_当月支払額（税込）←支払明細の[支払予定日]の年月 = [対象年月] かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				////if (strSELDTYM001.equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				////WK_当月支払額（税込）←支払明細の[支払日]の年月 = [対象年月] かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				//if (!"".equals(strSHIHARAIBI) && !"0".equals(strSHIHARAIBI) && strSELDTYM001.equals(strSHIHARAIBI.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				////2012/09/18 B票対応
				
				//WK_当月支払額（税込）
				// ← [支払予定日] = 対象年月日（前回締の翌日～本締日） 
				//    かつ　[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				if (((strWkSTADT[0].compareTo(strSHRDD) <= 0) && (strWkENDDT[0].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lTOUHAR_CAl = lTOUHAR_CAl.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					
				//--2016/08/01 MOD Start -----------------------------
				////2012/09/18 B票対応
				//////WK_当月相殺額（税込）←支払明細の[支払予定日]の年月 = [対象年月] かつ支払明細の[支払種別] >= ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				////} else if (strSELDTYM001.equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) >= Const.cPayCode_UserSet01) {
				////WK_当月相殺額（税込）←支払明細の[支払日]の年月 = [対象年月] かつ支払明細の[支払種別] >= ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				//} else if (!"".equals(strSHIHARAIBI) && !"0".equals(strSHIHARAIBI) &&strSELDTYM001.equals(strSHIHARAIBI.substring(0, 6)) && Integer.valueOf(strSIHCD) >= Const.cPayCode_UserSet01) {
				////2012/09/18 B票対応
					
				//WK_当月相殺額（税込）
				//　← [支払予定日] = 対象年月日（前回締の翌日～本締日） 
				//     かつ [支払種別] >= ComConst.cPayCode_UserSet01の支払明細の[支払額（税込）]の合計
				} else if (((strWkSTADT[0].compareTo(strSHRDD) <= 0) && (strWkENDDT[0].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) >= Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lTOUSOU_CAl = lTOUSOU_CAl.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));

				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額1←支払明細の[支払予定日]の年月 = ([対象年月] + 1ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計
				////WK_支払予定消費税額1←支払明細の[支払予定日]の年月 = ([対象年月] + 1ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 1).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額1
				// ← [支払予定日] = 次回の対象年月日
				//    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[1].compareTo(strSHRDD) <= 0) && (strWkENDDT[1].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI1 = lWK_SYOTEI1.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI1 = lWK_SZYOTEI1.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI1 = lWK_SZYOTEI1.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
					
				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額2←支払明細の[支払予定日]の年月 = ([対象年月] + 2ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計	
				////WK_支払予定消費税額2←支払明細の[支払予定日]の年月 = ([対象年月] + 2ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 2).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額2　
				// ← [支払予定日] = 2回後の対象年月日
			    //    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[2].compareTo(strSHRDD) <= 0) && (strWkENDDT[2].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI2 = lWK_SYOTEI2.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI2 = lWK_SZYOTEI2.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI2 = lWK_SZYOTEI2.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
					
					
				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額3←支払明細の[支払予定日]の年月 = ([対象年月] + 3ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計	
				////WK_支払予定消費税額3←支払明細の[支払予定日]の年月 = ([対象年月] + 3ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 3).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額3
				// ← [支払予定日] = 3回後の対象年月日
				//    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[3].compareTo(strSHRDD) <= 0) && (strWkENDDT[3].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI3 = lWK_SYOTEI3.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI3 = lWK_SZYOTEI3.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI3 = lWK_SZYOTEI3.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
					
				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額4←支払明細の[支払予定日]の年月 = ([対象年月] + 4ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計	
				////WK_支払予定消費税額4←支払明細の[支払予定日]の年月 = ([対象年月] + 4ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 4).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額4
				// ← [支払予定日] = 4回後の対象年月日
				//    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[4].compareTo(strSHRDD) <= 0) && (strWkENDDT[4].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI4 = lWK_SYOTEI4.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI4 = lWK_SZYOTEI4.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI4 = lWK_SZYOTEI4.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
				
				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額5←支払明細の[支払予定日]の年月 = ([対象年月] + 5ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計	
				////WK_支払予定消費税額5←支払明細の[支払予定日]の年月 = ([対象年月] + 5ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 5).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額5
				// ← [支払予定日] = 5回後の対象年月日
				//    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[5].compareTo(strSHRDD) <= 0) && (strWkENDDT[5].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI5 = lWK_SYOTEI5.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI5 = lWK_SZYOTEI5.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI5 = lWK_SZYOTEI5.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
					
				//--2016/08/01 MOD Start -----------------------------
				////WK_支払予定金額6←支払明細の[支払予定日]の年月 = ([対象年月] + 6ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の([支払額（税込）] - [内消費税])の合計	
				////WK_支払予定消費税額6←支払明細の[支払予定日]の年月 = ([対象年月] + 6ヶ月) かつ支払明細の[支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				//} else if (getYYYYMMAfterAdd(strSELDTYM001, 6).equals(strSHRDD.substring(0, 6)) && Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				
				//WK_支払予定消費税額6
				// ← [支払予定日] = 6回後の対象年月日
				//    かつ [支払種別] < ComConst.cPayCode_UserSet01の支払明細の[内消費税]の合計
				} else if (((strWkSTADT[6].compareTo(strSHRDD) <= 0) && (strWkENDDT[6].compareTo(strSHRDD) >= 0))
						&& Integer.valueOf(strSIHCD) < Const.cPayCode_UserSet01) {
				//--2016/08/01 MOD End   ----------------------------
					
					lWK_SYOTEI6 = lWK_SYOTEI6.add(new BigDecimal(CommonMethod.changeZero(strSIHKN))).subtract(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　S
					//lWK_SZYOTEI6 = lWK_SZYOTEI6.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
					lWK_SZYOTEI6 = lWK_SZYOTEI6.add(new BigDecimal(CommonMethod.changeZero(strZEIKN)));
					//ピックアップテスト No.28　対応修正　E
				}
			}
			lSIHKN = lSIHKN.add(new BigDecimal(CommonMethod.changeZero(strSIHKN)));
		}
		
		//WK_当月支払額（税込）
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOUHAR", String.valueOf(lTOUHAR_CAl));
		//WK_当月相殺額（税込）
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOUSOU", String.valueOf(lTOUSOU_CAl));
		//WK_支払予定金額1
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI11", String.valueOf(lWK_SYOTEI1));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI1", String.valueOf(lWK_SYOTEI1));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定金額2
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI22", String.valueOf(lWK_SYOTEI2));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI2", String.valueOf(lWK_SYOTEI2));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定金額3
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI33", String.valueOf(lWK_SYOTEI3));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI3", String.valueOf(lWK_SYOTEI3));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定金額4
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI44", String.valueOf(lWK_SYOTEI4));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI4", String.valueOf(lWK_SYOTEI4));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定金額5
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI55", String.valueOf(lWK_SYOTEI5));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI5", String.valueOf(lWK_SYOTEI5));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定金額6
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI66", String.valueOf(lWK_SYOTEI6));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SYOTEI6", String.valueOf(lWK_SYOTEI6));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額1
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI11", String.valueOf(lWK_SZYOTEI1));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI1", String.valueOf(lWK_SZYOTEI1));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額2
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI22", String.valueOf(lWK_SZYOTEI2));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI2", String.valueOf(lWK_SZYOTEI2));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額3
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI33", String.valueOf(lWK_SZYOTEI3));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI3", String.valueOf(lWK_SZYOTEI3));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額4
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI44", String.valueOf(lWK_SZYOTEI4));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI4", String.valueOf(lWK_SZYOTEI4));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額5
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI55", String.valueOf(lWK_SZYOTEI5));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI5", String.valueOf(lWK_SZYOTEI5));
		//ピックアップテスト No.28　対応削除　E
		//WK_支払予定消費税額6
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI66", String.valueOf(lWK_SZYOTEI6));
		//ピックアップテスト No.28　対応削除　S
		//CommonMethod.setItemValue("KGMNT0230C", "01", "WK_SZYOTEI6", String.valueOf(lWK_SZYOTEI6));
		//ピックアップテスト No.28　対応削除　E
		
		//WK_当月支払合計←[当月支払額（税込）] + [当月相殺額（税込）]	
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOUHAR_CAL", 
				String.valueOf(lTOUHAR_CAl.add(lTOUSOU_CAl)));
																						
		//WK_当月残高←[前月末残高] + WK_当月仕入額 - WK_当月支払合計
		//[前月末残高]
		String strZENZAN = CommonMethod.getItemValue("KGMNT0230C", "01", "ZENZAN").FldValue;
		BigDecimal strTOUZAN = getZeroWhenNull(strZENZAN).add(strTOUSIR_CAL).
				subtract(new BigDecimal(String.valueOf(lTOUHAR_CAl.add(lTOUSOU_CAl)))); 
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOUZAN", strTOUZAN.toString());
																						
		//2012/08/20 CS対応
		//WK_当月発生相殺額←支払明細の[発生月] = [対象年月] かつ
		//支払明細の[支払種別] >= ComConst.cPayCode_UserSet01の
		//支払明細の[支払額（税込）]－[内消費税]の合計
	
		//WK_当月発生相殺税額←支払明細の[発生月] = [対象年月] かつ
		//支払明細の[支払種別] >= ComConst.cPayCode_UserSet01の
		//支払明細の[内消費税]の合計
		int rowCnt = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
		long sumSousai = 0;
		long sumSousaiZei = 0;
		
		//対象終了日([対象年月]&[対象締日])
		String strWK_ENDYMD = CommonMethod.getItemValue("KGMNT0230C","01", "WK_ENDYMD").FldValue;  //--2016/08/01 ADD
		
		for(int i = 0 ; i < rowCnt ; i++){
			
			//--2016/08/01 MOD Start -----------------------------
			//String strHSIYYMM = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "HSIYYMM");
			String strHSIYYMMDD = CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "HSIYYMMDD");
			//--2016/08/01 MOD End   -----------------------------
			int intSIHCD = getZeroWhenNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD")).intValue();
			
			//--2016/08/01 MOD Start -----------------------------
			//if(strHSIYYMM.equals(strSELDTYM001) && intSIHCD >= Const.cPayCode_UserSet01){
			if(strHSIYYMMDD.equals(strWK_ENDYMD) && intSIHCD >= Const.cPayCode_UserSet01){
			//--2016/08/01 MOD End   -----------------------------
				long longSIHKN = getZeroWhenNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN")).longValue();
				long longZEIKN = getZeroWhenNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN")).longValue();
				sumSousai += (longSIHKN - longZEIKN);
				sumSousaiZei += longZEIKN;
			}
		}
		CommonMethod.setItemValue("KGMNT0230C", "01", "HASSEISOSAI", String.valueOf(sumSousai));
		CommonMethod.setItemValue("KGMNT0230C", "01", "HASSEISOSAI_ZEI", String.valueOf(sumSousaiZei));
		//2012/08/20 CS対応
		//WK_当月発生支払予定←WK_当月仕入額 - ([当月発生相殺額] + [当月発生相殺税額])	
		//当月発生相殺額
		String strHASSEISOSAI = CommonMethod.getItemValue("KGMNT0230C", "01", "HASSEISOSAI").FldValue;
		//当月発生相殺税額
		String strHASSEISOSAI_ZEI = CommonMethod.getItemValue("KGMNT0230C", "01", "HASSEISOSAI_ZEI").FldValue;
		//ピックアップテスト No.28　対応修正　S
		//BigDecimal strHASSEIYOTEI = strTOUSIR_CAL.subtract(new BigDecimal(strHASSEISOSAI)).add(getZeroWhenNull(strHASSEISOSAI_ZEI)); 
		BigDecimal strHASSEIYOTEI = strTOUSIR_CAL.subtract(new BigDecimal(strHASSEISOSAI)).subtract(getZeroWhenNull(strHASSEISOSAI_ZEI)); 
		//ピックアップテスト No.28　対応修正　E
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_HASSEIYOTEI", strHASSEIYOTEI.toString());
																						
		//WK_当月保留額←	[前月末残高] + WK_当月仕入額 - 支払明細の[支払額（税込）]の合計																				
		BigDecimal StrTOURYUHO = getZeroWhenNull(strZENZAN).add(strTOUSIR_CAL).subtract(new BigDecimal(String.valueOf(lSIHKN)));
		CommonMethod.setItemValue("KGMNT0230C", "01", "WK_TOURYUHO", StrTOURYUHO.toString());
		
		//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加   S  
		//業務チェックを行う
		KGMNT0230C01Check chk = new KGMNT0230C01Check();
		if (!chk.CalcSum_Check()) {
			return false;
		}
		return true;
		//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加   E  
	}
	
	/**
	 * 文字列がNULLまたは""の場合、0を返す。その以外の場合BigDecimalに変更して返す。
	 * @param strKingaku 処理される文字列
	 */
	private BigDecimal getZeroWhenNull(String strKingaku) {
		if (strKingaku == null || "".equals(strKingaku)) {
			return new BigDecimal(0);
		}
		return new BigDecimal(strKingaku);
	}
	
	/**
	 * 対象年月がnヶ月加算した結果を返す
	 * @param n 対象年月
	 * @param n 加算値
	 * @throws ParseException 
	 */
	private String getYYYYMMAfterAdd(String strYYYYMM, int n) throws ParseException {
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMM", Locale.US);
        Date date = simpleDateFormat.parse(strYYYYMM);
        Calendar calender = Calendar.getInstance();
        calender.setTime(date);
        calender.add(Calendar.MONTH, n);
        simpleDateFormat.format(calender.getTime());
        return simpleDateFormat.format(calender.getTime()).toString();
	}
	
	/**
	 * 仕入先情報取得
	 * @param request リクエスト
	 * 
	 */
	public static void Ajax_KGMNT_01(HttpServletRequest request){
		try{
			String CodeName = "";
			String procID = "";
			String paramV = "";
				
			Enumeration names = (Enumeration)request.getParameterNames();
			while(names.hasMoreElements()){
				String key = (String)names.nextElement();			
				if(key.equals("PROCID")){
					procID = request.getParameter(key);
				} else if(key.equals("PARAMV")){
					paramV = request.getParameter(key);
				}	
			}

			CommonMethod.setItemValue("KGMNT0230C", "01", "DSHICD", paramV);

			CommonProcedure comProc = new CommonProcedure();
			comProc.selectProcedure("KGMNT0230C", "01", procID);

			if(comProc.RowCnt > 0){
				CodeName = "SHIKJ:" + CommonMethod.getItemValue("KGMNT0230C", "01", "SHIKJ").FldValue;
				CommonMethod.getItemValue("KGMNT0230C", "01", "SHIKJ").setFldLabel(CommonMethod.getItemValue("KGMNT0230C", "01", "SHIKJ").FldValue);
				CodeName += ",KGSJOKEN:" + CommonMethod.getItemValue("KGMNT0230C", "01", "KGSJOKEN").FldValue;
				CodeName += ",KGSJOKENKJ:" + CommonMethod.getItemValue("KGMNT0230C", "01", "KGSJOKENKJ").FldValue;
				//2012/08/20 CS対応
				CodeName += ",WK_KAIHASUKBN:" + CommonMethod.getItemValue("KGMNT0230C", "01", "WK_KAIHASUKBN").FldValue;
				//2012/08/20 CS対応
				//--2016/08/01 ADD Start -----------------------------
				CodeName += ",DSSIME:" + CommonMethod.getItemValue("KGMNT0230C", "01", "DSSIME").FldValue;
				CodeName += ",DSTSIME:" + CommonMethod.getItemValue("KGMNT0230C", "01", "DSTSIME").FldValue;
				CodeName += ",DSSHRDD:" + CommonMethod.getItemValue("KGMNT0230C", "01", "DSSHRDD").FldValue;
				CodeName += ",DSTSHRDD:" + CommonMethod.getItemValue("KGMNT0230C", "01", "DSTSHRDD").FldValue;
				//--2016/08/01 ADD End   -----------------------------
				
				CommonMethod.getItemValue("KGMNT0230C", "01", "KGSJOKENKJ").setFldLabel(CommonMethod.getItemValue("KGMNT0230C", "01", "KGSJOKENKJ").FldValue);
			} else {
				CodeName = "Data None";
			}

			FacesContext context = FacesContext.getCurrentInstance();
			CommonAjaxBean ajaxBean = (CommonAjaxBean)context.getApplication().createValueBinding("#{CommonAjaxBean}").getValue(context);
			ajaxBean.setCODENAME(CodeName);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	/**
	 * 支払種別情報取得
	 * @param request リクエスト
	 * 
	 */
	public static void Ajax_KGMNT_02(HttpServletRequest request){
		try{
			String CodeName = "";
			int row = 0;
			String procID = "";
			String paramV = "";
				
			Enumeration names = (Enumeration)request.getParameterNames();
			while(names.hasMoreElements()){
				String key = (String)names.nextElement();			
				if(key.equals("PROCID")){
					procID = request.getParameter(key);
				} else if(key.equals("PARAMV")){
					paramV = request.getParameter(key);
				} else if(key.equals("ROW")){
					row = Integer.parseInt(request.getParameter(key));
				}
			}

			CommonMethod.setRowModelData("KGMNT0230C", "01", "001", row, "SIHCD", paramV);

			CommonProcedure comProc = new CommonProcedure();
			comProc.selectProcedure("KGMNT0230C", "01", "001", procID, row );

			if(comProc.RowCnt > 0){
				CodeName = "TEKIYO:" + CommonMethod.getRowModelData("KGMNT0230C", "01", "001", row, "TEKIYO");	//TEKIYO
			} else {
				CodeName = "Data None";
			}

			FacesContext context = FacesContext.getCurrentInstance();
			CommonAjaxBean ajaxBean = (CommonAjaxBean)context.getApplication().createValueBinding("#{CommonAjaxBean}").getValue(context);
			ajaxBean.setCODENAME(CodeName);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	
	//2023/09/13_KDP導入_sys.担当F2_ADD_START
	/**
	 * 支払予定日情報取得
	 * @param request リクエスト
	 * 
	 */
	public static void Ajax_KGMNT_03(HttpServletRequest request){
		try{
			String CodeName = "";
			int row = 0;
			String procID = "";
			String paramV = "";
				
			Enumeration names = (Enumeration)request.getParameterNames();
			while(names.hasMoreElements()){
				String key = (String)names.nextElement();			
				if(key.equals("PROCID")){
					procID = request.getParameter(key);
				} else if(key.equals("PARAMV")){
					paramV = request.getParameter(key);
				} else if(key.equals("ROW")){
					row = Integer.parseInt(request.getParameter(key));
				}
			}

			//2023/09/22_KDP導入_sys.担当F2_MOD_KG-UT-B016_START
			//CommonMethod.setRowModelData("KGMNT0230C", "01", "001", row, "HSIYYMM", paramV);
			CommonMethod.setRowModelData("KGMNT0230C", "01", "001", row, "HSIYYMMDD", paramV);
			//2023/09/22_KDP導入_sys.担当F2_MOD_KG-UT-B016_END

			CommonProcedure comProc = new CommonProcedure();
			comProc.selectProcedure("KGMNT0230C", "01", "001", procID, row );

			if(comProc.RowCnt > 0){
				CodeName = "SHRDD:" + CommonMethod.getRowModelData("KGMNT0230C", "01", "001", row, "SHRDD");	//SHRDD
			} else {
				CodeName = "Data None";
			}

			FacesContext context = FacesContext.getCurrentInstance();
			CommonAjaxBean ajaxBean = (CommonAjaxBean)context.getApplication().createValueBinding("#{CommonAjaxBean}").getValue(context);
			ajaxBean.setCODENAME(CodeName);
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
		
	}
	//2023/09/13_KDP導入_sys.担当F2_ADD_END
}

