//--2016/02/01 同一の[発生月][支払種別][支払予定日]が複数行入力されている場合は、エラーとする
//--2016/08/01 ACEカスタマイズ対応 
package com.hitachijoho.retail.logic.KG;

import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.faces.FacesException;
import javax.sql.RowSet;

import com.hitachijoho.retail.common.CommonMethod;
import com.hitachijoho.retail.common.CommonProcedure;
import com.hitachijoho.retail.common.Const;
import com.hitachijoho.retail.common.ControlFieldBean;

/**　買掛支払保守　業務チェック処理							
 * @author syou　2012/03/20								
 * @history whizen syou 2012/04/11  2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加									
 * @history whizen syou 2012/04/19   【BERS2CT-000034対応】								
 */	
public class KGMNT0230C01Check_P {

	/**
	 * Ｆ1（照会）押下時ボタン押下時　チェック処理
	 * @return false:エラー　true:正常
	 */
	public boolean F01_Check() {
		RowSet retRS = null;
		try {
			CommonProcedure comProc = new CommonProcedure();
			//[代表仕入先コード]をチェックする
			//[代表仕入先コード] ＝ 空白の場合は、以下の処理を行う
			String strDSHICD = CommonMethod.getItemValue("KGMNT0230C","01", "DSHICD").FldValue;
			
			retRS = comProc.selectProcedure_RtnSet("KGMNT0230C", "01", "PS_KGMNT0230C01S001");
			if (retRS.next()) {
				//仕入先情報取得を取得し、表示を行なう
				//【20120419】 【肖】 【BERS2CT-000034対応】 【開始】
				//comProc.selectProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01S001");
				//仕入先名
				CommonMethod.setItemValue("KGMNT0230C", "01", "SHIKJ", CommonMethod.exchangeNull(retRS.getString("SHIKJ")));
				//支払条件
				CommonMethod.setItemValue("KGMNT0230C", "01", "KGSJOKEN", CommonMethod.exchangeNull(retRS.getString("KGSJOKEN")));
				//支払条件名称
				CommonMethod.setItemValue("KGMNT0230C", "01", "KGSJOKENKJ", CommonMethod.exchangeNull(retRS.getString("KGSJOKENKJ")));
				//--2016/08/01 ADD Start -----------------------------
				//締日
				CommonMethod.setItemValue("KGMNT0230C", "01", "DSSIME", CommonMethod.exchangeNull(retRS.getString("DSSIME")));
				//中締日
				CommonMethod.setItemValue("KGMNT0230C", "01", "DSTSIME", CommonMethod.exchangeNull(retRS.getString("DSTSIME")));
				//支払日
				CommonMethod.setItemValue("KGMNT0230C", "01", "DSSHRDD", CommonMethod.exchangeNull(retRS.getString("DSSHRDD")));
				//中締支払日
				CommonMethod.setItemValue("KGMNT0230C", "01", "DSTSHRDD", CommonMethod.exchangeNull(retRS.getString("DSTSHRDD")));
				//対象開始日
				CommonMethod.setItemValue("KGMNT0230C", "01", "WK_STRYMD", CommonMethod.exchangeNull(retRS.getString("WK_STRYMD")));
				//対象終了日
				CommonMethod.setItemValue("KGMNT0230C", "01", "WK_ENDYMD", CommonMethod.exchangeNull(retRS.getString("WK_ENDYMD")));
				//--2016/08/01 ADD End   -----------------------------
				
				//取得した代表仕入先コードと[代表仕入先コード]が異なる場合は、エラーとする
				if (!strDSHICD.equals(CommonMethod.exchangeNull(retRS.getString("DSHICD")))) {
					CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00430", "代表仕入先");
					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");
					return false;
				}
				
			//} else {
			//	//仕入先情報を取得できなかった場合は、エラーとする
			//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00430", "代表仕入先");
			//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");
			//	return false;
			}
			//【20120419】 【肖】 【BERS2CT-000034対応】 【終了】
			
			//--2016/08/01 MOD Start -----------------------------
			////[対象年月]をチェックする
			////[対象年月]が未来日(VS#KAIKAKEDT8の先頭６桁より大きい)の場合は、エラーとする
			//String strKAIKAKEDT8 = CommonMethod.getSessionValue("KAIKAKEDT8");
			//String strSELDTYM001 = CommonMethod.getItemValue("KGMNT0230C","01", "SELDTYM001").FldValue;
			//if (strSELDTYM001.compareTo(strKAIKAKEDT8.substring(0, 6)) > 0) {
			//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01050", "");
			//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "SELDTYM001");
			//	return false;
			//}
			
			//対象締日
			String strSIME = CommonMethod.getItemValue("KGMNT0230C","01", "SIME").FldValue;
			//締日
			String strDSSIME = CommonMethod.getItemValue("KGMNT0230C","01", "DSSIME").FldValue;
			//中締日
			String strDSTSIME = CommonMethod.getItemValue("KGMNT0230C","01", "DSTSIME").FldValue;
			//[対象締日]　≠　[締日]　且つ　[対象締日]　≠　[中締日]　の場合、エラー
			if(!strSIME.equals(strDSSIME) && !strSIME.equals(strDSTSIME)){
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00430", "指定の代表仕入先には、対象締日と一致する締日（中締日）");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");
				return false;
			}
			
			//セッション変数[当月買掛締日（８桁）]
			String strKAIKAKEDT8 = CommonMethod.getSessionValue("KAIKAKEDT8");
			//対象終了日([対象年月]&[対象締日])
			String strWK_ENDYMD = CommonMethod.getItemValue("KGMNT0230C","01", "WK_ENDYMD").FldValue;
			// 対象年月日が未来日の場合、エラー。
			if (strWK_ENDYMD.compareTo(strKAIKAKEDT8) > 0) {
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01050", "");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "SELDTYM001");
				return false;
			}
			//--2016/08/01 MOD End   -----------------------------
			
			//買掛マスタのレコード件数を取得する
			//レコードが存在しない場合 ( #[CNT]＝0 )、エラーとする
			/* 20121203 INOUE 運用上締め前に支払データを入力するためチェックを外した。
			comProc.selectProcedure("KGMNT0230C", "01", "PS_KGMNT0230C01S005");
			if (comProc.RowCnt == 0) {
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00430", "買掛マスタ");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "DSHICD");
				return false;
			}
			*/
			return true;
		} catch (Exception e) {
			throw new FacesException(e);
		} finally {
			if(retRS != null){ 
				try { retRS.close();} 
				catch (SQLException e1) {} 
			}
		}
	}
	
	/**
	 * Ｆ2（更新）押下時ボタン押下時　チェック処理
	 * @return false:エラー　true:正常
	 */
	public boolean F02_Check() {
		RowSet retRS = null;
		try {
			//[買掛明細]グループをチェック
			//[当月消費税] ＝ 空白 の場合、0をセットする
			String strTOUZEI = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUZEI").FldValue;
			if (strTOUZEI == null || "".equals(strTOUZEI)) {
				CommonMethod.setItemValue("KGMNT0230C", "01", "TOUZEI", "0");
			}
			//[当月発生相殺税額] ＝ 空白 の場合、0をセットする
			String strHASSEISOSAI_ZEI = CommonMethod.getItemValue("KGMNT0230C", "01", "HASSEISOSAI_ZEI").FldValue;
			if (strHASSEISOSAI_ZEI == null || "".equals(strHASSEISOSAI_ZEI)) {
				CommonMethod.setItemValue("KGMNT0230C", "01", "HASSEISOSAI_ZEI", "0");
			}

			//対象年月
			String strSELDTYM001 = CommonMethod.getItemValue("KGMNT0230C", "01", "SELDTYM001").FldValue;
			//--2016/08/01 ADD Start -----------------------------
			//対象開始日
			String strWK_STRYMD = CommonMethod.getItemValue("KGMNT0230C","01", "WK_STRYMD").FldValue;
			//対象終了日([対象年月]&[対象締日])
			String strWK_ENDYMD = CommonMethod.getItemValue("KGMNT0230C","01", "WK_ENDYMD").FldValue;
			//締日
			String strDSSIME = CommonMethod.getItemValue("KGMNT0230C","01", "DSSIME").FldValue;
			//中締日
			String strDSTSIME = CommonMethod.getItemValue("KGMNT0230C","01", "DSTSIME").FldValue;
			//--2016/08/01 ADD End   -----------------------------
			
			//[支払明細]グループをチェック
			//[発生月] ＝ 空白 かつ [支払予定日] ＝ 空白 かつ [支払種別] ＝ 空白 かつ [支払額（税込）] ＝ 空白 かつ [消費税] ＝ 空白 かつ [支払日] ＝ 空白 かつ[備考] ＝ 空白 の場合は、チェックを行わない
			int rowCount = CommonMethod.getModelDataCount("KGMNT0230C", "01", "001");
			int i = 0;
			//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add Start 
			int intUpdcnt = 0;
			//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add End 
			for (i = 0;i < rowCount;i++) {
				//--2016/08/01 MOD Start -----------------------------
				////発生月
				//String strHSIYYMM = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "HSIYYMM"));
				//発生締日
				String strHSIYYMMDD = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "HSIYYMMDD"));
				//--2016/08/01 MOD End   -----------------------------
				//支払種別
				String strSIHCD = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHCD"));
				//支払額（税込）
				String strSIHKN = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SIHKN"));
				//内消費税
				String strZEIKN = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN"));
				//支払予定日
				String strSHRDD = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SHRDD"));
				//支払日
				String strSHIHARAIBI = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "SHIHARAIBI"));
				//2012/10/03 B票対応
				if (!"".equals(strSHIHARAIBI)){
					if(Integer.parseInt(strSHIHARAIBI) == 0){
						strSHIHARAIBI = "";
					}
				}
				//2012/10/03 B票対応
				//備考
				String strBIKO = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", i, "BIKO"));
				//--2016/08/01 MOD Start -----------------------------
				//if (!"".equals(strHSIYYMM) ||  !"".equals(strSIHCD) || !"".equals(strSIHKN) 
				if (!"".equals(strHSIYYMMDD) ||  !"".equals(strSIHCD) || !"".equals(strSIHKN) 
				//--2016/08/01 MOD End   -----------------------------
						|| !"".equals(strZEIKN) || !"".equals(strSHRDD) || !"".equals(strSHIHARAIBI) || !"".equals(strBIKO)) {
					
					//--2016/08/01 MOD Start -----------------------------
					////[発生月]のチェックを行う
					////[発生月] ＝ 空白の場合、エラーとする
					//if ("".equals(strHSIYYMM)) {
					//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00140", "発生月");
					//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMM");
					//	return false;
					//}
					////[発生月] ＞ [対象年月]の場合、エラーとする
					//if (strHSIYYMM.compareTo(strSELDTYM001) > 0) {
					//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01050", "");
					//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMM");
					//	return false;
					//}
					//[発生締日]のチェックを行う
					//[発生締日] ＝ 空白の場合、エラーとする
					if ("".equals(strHSIYYMMDD)) {
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00140", "発生締日");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMMDD");
						return false;
					}
					//[発生締日] ＞ [対象終了日] の場合、エラーとする
					if (strHSIYYMMDD.compareTo(strWK_ENDYMD) > 0) {
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01050", "");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMMDD");
						return false;
					}
					
					String chkHsiYmdFLG = "0";
					//[締日] or [中締日] = 99(末日)の場合
					if("99".equals(strDSSIME) || "99".equals(strDSTSIME)){
						//[発生締日]（YYYYMM型）の末日取得
						SimpleDateFormat df = new SimpleDateFormat("yyyyMM");  	
						Date date = df.parse(strHSIYYMMDD.substring(0, 6));
						Calendar cal = Calendar.getInstance();
						cal.setTime(date);
						String strMATUBI = String.valueOf(cal.getActualMaximum(Calendar.DATE));
						
						String chk_strDSSIME = "";
						String chk_strDSTSIME = "";
						if("99".equals(strDSSIME)){
							chk_strDSSIME = strMATUBI;
						}else{
							chk_strDSSIME = strDSSIME;
						}
						if("99".equals(strDSTSIME)){
							chk_strDSTSIME = strMATUBI;
						}else{
							chk_strDSTSIME = strDSTSIME;
						}
						
						// [発生締日]のDD型 ≠　(「[発生締日]（YYYYMM型）の末日」&& 99(末日)以外の[締日]&[中締日])
						if(!strHSIYYMMDD.substring(6).equals(chk_strDSSIME) &&
								!strHSIYYMMDD.substring(6).equals(chk_strDSTSIME)){
							chkHsiYmdFLG = "1";
						}
					}
					//[締日] and [中締日] ≠ 99(末日)の場合
					else{
						//[発生締日]のDD型 ≠ ([締日]&[中締日])の場合、エラーとする
						if (!strHSIYYMMDD.substring(6).equals(strDSSIME) && 
								!strHSIYYMMDD.substring(6).equals(strDSTSIME)) {
							chkHsiYmdFLG = "1";
						}
					}
					if("1".equals(chkHsiYmdFLG)){
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E60030", "締日（中締日）");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMMDD");
						return false;
					}
					//--2016/08/01 MOD End   -----------------------------
					
					//--2024/05/13 ADD（新規入力行で発生締日が過去はエラー）-STR  sys.Endo
					//--発生締日が活性の場合、新規入力項目と判断する
					//Object Obj_HSIYYMMDD = CommonMethod.getRowModelDisabled("KGMNT0230C", "01", "001" , i , "HSIYYMMDD");
					if (CommonMethod.getRowModelDisabled("KGMNT0230C", "01", "001", i, "HSIYYMMDD").toString().equals("table-cell")) {
						//[発生締日] < セッション変数[当月買掛締日(８桁)　] の場合、エラーとする
						if (strHSIYYMMDD.compareTo(CommonMethod.getSessionValue("KAIKAKEDT8")) < 0) {
							CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E57080", "");
							CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMMDD");
							return false;
						}	
					}			
					//--2024/05/13 ADD（新規入力行で発生締日が過去はエラー）-END  sys.Endo
					
					//[支払予定日]のチェックを行う
					//[支払予定日] ＝ 空白の場合、エラーとする
					if ("".equals(strSHRDD)) {
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00140", "支払予定日");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHRDD");
						return false;
					}
					//2012/10/02 B票対応
					//--2016/08/01 MOD Start -----------------------------
					//[支払予定日]＜[対象年月]&01（対象年月の１日）の場合はエラーとする。
					//if (strSHRDD.compareTo(strSELDTYM001+"01") < 0 ){
					//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04730", "支払予定日に対象年月");
					
					//[支払予定日]＜[対象開始日]の場合はエラーとする。
					if (strSHRDD.compareTo(strWK_STRYMD) < 0 ){
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04730", "支払予定日に対象年月日");
						//--2016/08/01 MOD End   -----------------------------
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHRDD");
						return false;
					}
					//2012/10/02 B票対応
					//2012/09/18 B票対応
//					//[支払予定] ≦ 前月買掛締日(VS#ZEN_KAIKAKEDT) の場合、エラーとする
//					String strZEN_KAIKAKEDT = CommonMethod.getSessionValue("ZEN_KAIKAKEDT");
//					//if (strSHRDD.compareTo(strZEN_KAIKAKEDT) <= 0) {
//					if (strSHIHARAIBI.compareTo(strZEN_KAIKAKEDT) <= 0) {
//						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01100", "");
//						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHRDD");
//						return false;
//					}
//					//[支払予定日]の年月＝[対象年月] かつ[支払日] ＝ 空白の場合、エラーとする
					/* 20121203 INOUE 運用上締め前に支払データを入力するためチェックを外した。
					if (strSHRDD.substring(0, 6).equals(strSELDTYM001) && "".equals(strSHIHARAIBI)) {
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00140", "支払日");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHIHARAIBI");
						return false;
					}
					*/
					//[支払日]のチェックを行う。
					//2012/10/02 B票対応
//					//[支払予定日]　＞　[支払日]の場合、エラーとする。
//					if (!"".equals(strSHIHARAIBI) && !"0".equals(strSHIHARAIBI) && strSHRDD.compareTo(strSHIHARAIBI) > 0) {
//						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04730", "支払日には支払予定日");
//						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHIHARAIBI");
//						return false;
//					}
					//[支払日]＜[対象年月]&01（対象年月の１日）の場合はエラーとする。
					if (!"".equals(strSHIHARAIBI)){
						if(Integer.parseInt(strSHIHARAIBI) == 0){
							strSHIHARAIBI = "";
						}
					}
					//--2016/08/01 MOD Start -----------------------------
					//if (!"".equals(strSHIHARAIBI) && strSHIHARAIBI.compareTo(strSELDTYM001+"01") < 0 ){
					//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04730", "支払日に対象年月");
					
					//[支払日]＜[対象開始日]の場合はエラーとする。
					if (!"".equals(strSHIHARAIBI) && strSHIHARAIBI.compareTo(strWK_STRYMD) < 0 ){
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E04730", "支払日に対象年月日");
						//--2016/08/01 MOD End   -----------------------------
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SHIHARAIBI");
						return false;
					}
					//2012/10/02 B票対応
					//2012/09/18 B票対応
					//[支払種別]のチェックを行う
					//[支払種別] ＝ 空白の場合は、以下を処理する
					if ("".equals(strSIHCD)) {
						CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "TEKIYO", "");
						CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00140", "支払種別");
						CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":SIHCD");
						return false;
					} else {
						//摘要情報を取得して以下の項目をセットする
						CommonProcedure comProc = new CommonProcedure();
						comProc.selectProcedure("KGMNT0230C", "01", "001", "PS_KGMNT0230C01S004", i);
					}
					//[支払額（税込）] ＝ 空白 の場合、0をセットする
					if ("".equals(strSIHKN)) {
						CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "SIHKN", "0");
					}
					//[内消費税] ＝ 空白 の場合、0をセットする
					if ("".equals(strZEIKN)) {
						CommonMethod.setRowModelData("KGMNT0230C", "01", "001", i, "ZEIKN", "0");
					}
					
					//同一の[支払予定日]と[支払種別]が複数行入力されている場合は、エラーとする
					/* 20130611 DEL INOUE START
					for (int j = i + 1;j < rowCount;j++) {
						//支払種別
						String strSIHCDNext = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "SIHCD"));
						//支払予定日
						String strSHRDDNext = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "SHRDD"));
						if (strSIHCDNext.equals(strSIHCD) && strSHRDDNext.equals(strSHRDD)) {
							CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00420", "支払予定日と支払種別");
							CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + j + ":SIHCD");
							return false;
						}
					}
					20130611 DEL INOUE END */
					
					//--2016/02/01 ADD Start -----------------------
					//支払年月
					String strSHRYYMM = strSHRDD.substring(0, 6);
					//チェック項目[支払日]
					String strChkDT = strSHIHARAIBI;
					//[支払日] ＝ 空白 or "0" の場合、[支払予定日]
					if("".equals(strSHIHARAIBI) || "0".equals(strSHIHARAIBI)){
						strChkDT = strSHRDD;
					}
					
					for (int j = i + 1; j < rowCount; j++) {
						//比較_支払予定日
						String strSHRDDtg = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "SHRDD"));
						//--2016/08/01 MOD Start -----------------------------
						////比較_発生月
						//String strHSIYYMMtg = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "HSIYYMM"));
						//比較_発生締日
						String strHSIYYMMDDtg = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "HSIYYMMDD"));
						//--2016/08/01 MOD End   -----------------------------
						//比較_支払種別
						String strSIHCDtg = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "SIHCD"));
						//比較_支払年月
						//--2017/08/10 MOD start -----支払予定日が未入力対応-----------------------------------------------------------
						String strSHRYYMMtg = "";
						if("".equals(strSHRDDtg)){
							strSHRYYMMtg = "000000";
						} else{
							strSHRYYMMtg = strSHRDDtg.substring(0, 6);
						}
						//String strSHRYYMMtg = strSHRDDtg.substring(0, 6);
						//--2017/08/10 MOD end ---------------------------------------------------------------------------------------
						//比較_支払日
						String strSHIHARAIBItg = CommonMethod.exchangeNull(CommonMethod.getRowModelData("KGMNT0230C", "01", "001", j, "SHIHARAIBI"));
						
						//比較_チェック項目[支払日]
						String strChkDTtg = strSHIHARAIBItg;
						//比較_[支払日] ＝ 空白 or "0" の場合、比較_[支払予定日]
						if("".equals(strSHIHARAIBItg) || "0".equals(strSHIHARAIBItg)){
							strChkDTtg = strSHRDDtg;
						}
						
						//--2016/08/01 MOD Start -----------------------------
						////同一の[発生月],[支払種別],[支払年月],チェック項目[予定日]が複数行入力されている場合は、エラーとする
						//if(strHSIYYMM.equals(strHSIYYMMtg) && strSIHCD.equals(strSIHCDtg)
						//		&& strSHRYYMM.equals(strSHRYYMMtg) && strChkDT.equals(strChkDTtg) ){
						//	CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00420", "発生月、支払種別、支払年月、支払日（支払予定日）");
						//	CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + j + ":HSIYYMM");
						//	return false;
						//}
						//同一の[発生締日],[支払種別],[支払年月],チェック項目[予定日]が複数行入力されている場合は、エラーとする
						if(strHSIYYMMDD.equals(strHSIYYMMDDtg) && strSIHCD.equals(strSIHCDtg)
								&& strSHRYYMM.equals(strSHRYYMMtg) && strChkDT.equals(strChkDTtg) ){
							CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00420", "発生締日、支払種別、支払年月、支払日（支払予定日）");
							CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + j + ":HSIYYMMDD");
							return false;
						}
						//--2016/08/01 MOD End   -----------------------------
					}
					//--2016/02/01 ADD End   -----------------------
					
					//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add Start 
					//--明細の登録行をカウントアップ
					intUpdcnt++;
					//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add End
				}else {
					//--2024/05/09 ADD sys.Endo
					//空白行のチェック追加
					//エラーメッセージ：E01360（空白行を含むことは出来ません。）
					CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E01360", "");
					CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:" + i + ":HSIYYMMDD");
					return false;
				}
				
			}
			
			//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add Start 
			//--明細で登録行がない場合はエラーとする
			if (intUpdcnt ==0){
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E00570", "");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "BTN_F02");
				return false;
			}
			//--2024/01/26 (KDP_AT1_B票-0176)対応 systech.Endo Add End
			
			//再計算結果（ワークエリア）と画面項目の内容が不一致の場合は、エラーとする
			//当月仕入額
			String strTOUSIR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUSIR_CAL").FldValue;
			String strWK_TOUSIR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSIR_CAL").FldValue;
			//当月支払額（税込）
			String strTOUHAR = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUHAR").FldValue;
			String strWK_TOUHAR = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR").FldValue;
			//当月相殺額（税込）
			String strTOUSOU = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUSOU").FldValue;
			String strWK_TOUSOU = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSOU").FldValue;
			//当月支払合計
			String strTOUHAR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUHAR_CAL").FldValue;
			String strWK_TOUHAR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR_CAL").FldValue;
			//[前月末残高]
			String strTOUZAN = CommonMethod.getItemValue("KGMNT0230C", "01", "TOUZAN").FldValue;
			String strWK_TOUZAN = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUZAN").FldValue;
			//当月発生支払予定
			String strHASSEIYOTEI = CommonMethod.getItemValue("KGMNT0230C", "01", "HASSEIYOTEI").FldValue;
			String strWK_HASSEIYOTEI = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_HASSEIYOTEI").FldValue;
			//当月保留額
			String strTOURYUHO = CommonMethod.getItemValue("KGMNT0230C", "01", "TOURYUHO").FldValue;
			String strWK_TOURYUHO = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOURYUHO").FldValue;
			//WK_支払予定金額1
			String strWK_SYOTEI1 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI1").FldValue;
			String strWK_SYOTEI11 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI11").FldValue;
			//WK_支払予定金額2
			String strWK_SYOTEI2 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI2").FldValue;
			String strWK_SYOTEI22 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI22").FldValue;
			//WK_支払予定金額3
			String strWK_SYOTEI3 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI3").FldValue;
			String strWK_SYOTEI33 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI33").FldValue;
			//WK_支払予定金額4
			String strWK_SYOTEI4 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI4").FldValue;
			String strWK_SYOTEI44 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI44").FldValue;
			//WK_支払予定金額5
			String strWK_SYOTEI5 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI5").FldValue;
			String strWK_SYOTEI55 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI55").FldValue;
			//WK_支払予定金額6
			String strWK_SYOTEI6 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI6").FldValue;
			String strWK_SYOTEI66 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI66").FldValue;
			//WK_支払予定消費税額1
			String strWK_SZYOTEI1 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI1").FldValue;
			String strWK_SZYOTEI11 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI11").FldValue;
			//WK_支払予定消費税額2
			String strWK_SZYOTEI2 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI2").FldValue;
			String strWK_SZYOTEI22 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI22").FldValue;
			//WK_支払予定消費税額3
			String strWK_SZYOTEI3 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI3").FldValue;
			String strWK_SZYOTEI33 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI33").FldValue;
			//WK_支払予定消費税額4
			String strWK_SZYOTEI4 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI4").FldValue;
			String strWK_SZYOTEI44 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI44").FldValue;
			//WK_支払予定消費税額5
			String strWK_SZYOTEI5 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI5").FldValue;
			String strWK_SZYOTEI55 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI55").FldValue;
			//WK_支払予定消費税額6
			String strWK_SZYOTEI6 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI6").FldValue;
			String strWK_SZYOTEI66 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI66").FldValue;
			
			//--2024/05/13 ADD　条件追加（買掛マスタなしの場合、「計算処理」実行のメッセージを出さない）-STR sys_Endo
			if ("".equals(strTOUSIR_CAL)){
				//空白（NULL）の場合、買掛マスタが作成されていない状態の為、計算が必要な処理はスキップ
				return true;
			}
			//--2024/05/13 ADD　条件追加（買掛マスタなしの場合、「計算処理」実行のメッセージを出さない）-END sys_Endo
			if (!CommonMethod.exchangeNull(strWK_TOUSIR_CAL).equals(CommonMethod.exchangeNull(strTOUSIR_CAL))
					|| !CommonMethod.exchangeNull(strWK_TOUHAR).equals(CommonMethod.exchangeNull(strTOUHAR)) 
					|| !CommonMethod.exchangeNull(strWK_TOUSOU).equals(CommonMethod.exchangeNull(strTOUSOU)) 
					|| !CommonMethod.exchangeNull(strWK_TOUHAR_CAL).equals(CommonMethod.exchangeNull(strTOUHAR_CAL)) 
					|| !CommonMethod.exchangeNull(strWK_TOUZAN).equals(CommonMethod.exchangeNull(strTOUZAN)) 
					|| !CommonMethod.exchangeNull(strWK_HASSEIYOTEI).equals(CommonMethod.exchangeNull(strHASSEIYOTEI)) 
					|| !CommonMethod.exchangeNull(strWK_TOURYUHO).equals(CommonMethod.exchangeNull(strTOURYUHO)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI11).equals(CommonMethod.exchangeNull(strWK_SYOTEI1)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI22).equals(CommonMethod.exchangeNull(strWK_SYOTEI2)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI33).equals(CommonMethod.exchangeNull(strWK_SYOTEI3)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI44).equals(CommonMethod.exchangeNull(strWK_SYOTEI4)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI55).equals(CommonMethod.exchangeNull(strWK_SYOTEI5)) 
					|| !CommonMethod.exchangeNull(strWK_SYOTEI66).equals(CommonMethod.exchangeNull(strWK_SYOTEI6)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI11).equals(CommonMethod.exchangeNull(strWK_SZYOTEI1)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI22).equals(CommonMethod.exchangeNull(strWK_SZYOTEI2)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI33).equals(CommonMethod.exchangeNull(strWK_SZYOTEI3)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI44).equals(CommonMethod.exchangeNull(strWK_SZYOTEI4)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI55).equals(CommonMethod.exchangeNull(strWK_SZYOTEI5)) 
					|| !CommonMethod.exchangeNull(strWK_SZYOTEI66).equals(CommonMethod.exchangeNull(strWK_SZYOTEI6))) {
				CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05240", "");
				CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "BTN_F02");
				return false;
			} 
			return true;
		} catch (Exception e) {
			throw new FacesException(e);
		} finally {
			if(retRS != null){ 
				try { retRS.close();} 
				catch (SQLException e1) {} 
			}
		}
	}

	//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加   S  
	/**
	 * 再計算の時、算出結果の桁数のチェック処理
	 * @return false:エラー　true:正常
	 */
	public boolean CalcSum_Check() {
		//当月仕入額
		String strWK_TOUSIR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSIR_CAL").FldValue;
		//当月支払額（税込）
		String strWK_TOUHAR = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR").FldValue;
		//当月相殺額（税込）
		String strWK_TOUSOU = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUSOU").FldValue;
		//当月支払合計
		String strWK_TOUHAR_CAL = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUHAR_CAL").FldValue;
		//[前月末残高]
		String strWK_TOUZAN = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOUZAN").FldValue;
		//当月発生支払予定
		String strWK_HASSEIYOTEI = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_HASSEIYOTEI").FldValue;
		//当月保留額
		String strWK_TOURYUHO = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_TOURYUHO").FldValue;
		
		//WK_支払予定金額1
		String strWK_SYOTEI11 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI11").FldValue;
		//WK_支払予定金額2
		String strWK_SYOTEI22 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI22").FldValue;
		//WK_支払予定金額3
		String strWK_SYOTEI33 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI33").FldValue;
		//WK_支払予定金額4
		String strWK_SYOTEI44 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI44").FldValue;
		//WK_支払予定金額5
		String strWK_SYOTEI55 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI55").FldValue;
		//WK_支払予定金額6
		String strWK_SYOTEI66 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SYOTEI66").FldValue;
		
		//WK_支払予定消費税額1
		String strWK_SZYOTEI11 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI11").FldValue;
		//WK_支払予定消費税額2
		String strWK_SZYOTEI22 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI22").FldValue;
		//WK_支払予定消費税額3
		String strWK_SZYOTEI33 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI33").FldValue;
		//WK_支払予定消費税額4
		String strWK_SZYOTEI44 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI44").FldValue;
		//WK_支払予定消費税額5
		String strWK_SZYOTEI55 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI55").FldValue;
		//WK_支払予定消費税額6
		String strWK_SZYOTEI66 = CommonMethod.getItemValue("KGMNT0230C", "01", "WK_SZYOTEI66").FldValue;
		
		//当月仕入額
		if (getStringOfSeisu(strWK_TOUSIR_CAL).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "TOUZEI");
			return false;
		}
		//当月支払額（税込）
		if (getStringOfSeisu(strWK_TOUHAR).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//当月相殺額（税込）
		if (getStringOfSeisu(strWK_TOUSOU).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//当月支払合計
		if (getStringOfSeisu(strWK_TOUHAR_CAL).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//[前月末残高]
		if (getStringOfSeisu(strWK_TOUZAN).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//当月発生支払予定
		if (getStringOfSeisu(strWK_HASSEIYOTEI).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "HASSEISOSAI_ZEI");
			return false;
		}
		//当月保留額
		if (getStringOfSeisu(strWK_TOURYUHO).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額1
		if (getStringOfSeisu(strWK_SYOTEI11).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額2
		if (getStringOfSeisu(strWK_SYOTEI22).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額3
		if (getStringOfSeisu(strWK_SYOTEI33).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額4
		if (getStringOfSeisu(strWK_SYOTEI44).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額5
		if (getStringOfSeisu(strWK_SYOTEI55).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		//WK_支払予定金額6
		if (getStringOfSeisu(strWK_SYOTEI66).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:SIHKN");
			return false;
		}
		
		//WK_支払予定消費税額1
		if (getStringOfSeisu(strWK_SZYOTEI11).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		//WK_支払予定消費税額2
		if (getStringOfSeisu(strWK_SZYOTEI22).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		//WK_支払予定消費税額3
		if (getStringOfSeisu(strWK_SZYOTEI33).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		//WK_支払予定消費税額4
		if (getStringOfSeisu(strWK_SZYOTEI44).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		//WK_支払予定消費税額5
		if (getStringOfSeisu(strWK_SZYOTEI55).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		//WK_支払予定消費税額6
		if (getStringOfSeisu(strWK_SZYOTEI66).length() > 14) {
			CommonMethod.setErrorHiddenItem("KGMNT0230C", "01", "", "E05260", "計算結果");
			CommonMethod.setItemValue("KGMNT0230C", "01", "HID_ERR_ITM", "dtBody001:0:ZEIKN");
			return false;
		}
		return true;
	}
	
	/**
	 * 文字列から正の文字列を取得する
	 * @param strString 処理される文字列
	 * @return 正の文字列
	 */
	public String getStringOfSeisu(String strString) {
		if (CommonMethod.exchangeNull(strString).indexOf("-") != -1) {
			return strString.substring(1, strString.length());
		} else {
			return strString;
		}
	}
	//2012.4.10 仕様変更 計算結果が桁数オーバーの確認を追加  E 
}

